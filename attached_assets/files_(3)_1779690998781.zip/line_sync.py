"""
ViP Line Sync — shared line-state backend for the Dante VM console/wall.

Stores the operational state of each line (idle / standby / onair) plus an
optional guest label, shared across every operator viewing the page from any
machine. Live updates are pushed to all connected clients over SSE so an
ON-AIR change shows up everywhere within a moment.

Run (single worker — SSE fan-out is in-process):
    uvicorn line_sync:app --host 0.0.0.0 --port 8090

Storage: SQLite file (LINE_DB env var, default ./lines.db). Survives restarts.
CORS is open so the page can be served from a different origin than this API.
"""

import asyncio
import json
import os
import sqlite3
import time
from contextlib import closing
from typing import Optional

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel

DB = os.environ.get("LINE_DB", "lines.db")
VALID_STATES = {"idle", "standby", "onair"}
MAX_LABEL = 120

app = FastAPI(title="ViP Line Sync")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # internal tool; lock down to your host(s) if you prefer
    allow_methods=["*"],
    allow_headers=["*"],
)


def _db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute(
        "CREATE TABLE IF NOT EXISTS lines ("
        "  id TEXT PRIMARY KEY,"
        "  state TEXT NOT NULL DEFAULT 'idle',"
        "  label TEXT NOT NULL DEFAULT '',"
        "  updated_at REAL NOT NULL DEFAULT 0"
        ")"
    )
    return conn


def all_lines() -> dict:
    with closing(_db()) as conn:
        rows = conn.execute("SELECT id, state, label, updated_at FROM lines").fetchall()
    return {
        r["id"]: {"state": r["state"], "label": r["label"], "updatedAt": r["updated_at"]}
        for r in rows
    }


# ---- in-process SSE subscribers ----
_subscribers: "set[asyncio.Queue]" = set()


async def _broadcast(event: dict) -> None:
    for q in list(_subscribers):
        try:
            q.put_nowait(event)
        except Exception:
            _subscribers.discard(q)


class LineUpdate(BaseModel):
    state: Optional[str] = None
    label: Optional[str] = None


@app.get("/lines")
def get_lines():
    return all_lines()


@app.put("/lines/{line_id}")
async def put_line(line_id: str, body: LineUpdate):
    now = time.time()
    with closing(_db()) as conn:
        cur = conn.execute(
            "SELECT state, label FROM lines WHERE id = ?", (line_id,)
        ).fetchone()
        state = cur["state"] if cur else "idle"
        label = cur["label"] if cur else ""

        if body.state is not None:
            if body.state not in VALID_STATES:
                return JSONResponse({"error": "invalid state"}, status_code=400)
            state = body.state
        if body.label is not None:
            label = body.label[:MAX_LABEL]

        conn.execute(
            "INSERT INTO lines (id, state, label, updated_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET "
            "  state = excluded.state, label = excluded.label, updated_at = excluded.updated_at",
            (line_id, state, label, now),
        )
        conn.commit()

    rec = {"state": state, "label": label, "updatedAt": now}
    await _broadcast({"type": "line", "id": line_id, **rec})
    return rec


@app.post("/reset")
async def reset_all():
    with closing(_db()) as conn:
        conn.execute("DELETE FROM lines")
        conn.commit()
    await _broadcast({"type": "reset", "updatedAt": time.time()})
    return {"ok": True}


@app.get("/events")
async def events(request: Request):
    q: asyncio.Queue = asyncio.Queue()
    _subscribers.add(q)

    async def gen():
        try:
            # immediate snapshot so a fresh client paints current state at once
            yield f"event: snapshot\ndata: {json.dumps(all_lines())}\n\n"
            while True:
                if await request.is_disconnected():
                    break
                try:
                    ev = await asyncio.wait_for(q.get(), timeout=15)
                    yield f"data: {json.dumps(ev)}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"   # keep proxies from closing the connection
        finally:
            _subscribers.discard(q)

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
    )


@app.get("/health")
def health():
    return {"ok": True, "subscribers": len(_subscribers)}
