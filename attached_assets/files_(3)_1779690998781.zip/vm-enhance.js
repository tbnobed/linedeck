/* =============================================================
   vm-enhance.js  —  drop-in add-on (does NOT touch vms.js)

   Adds, to every VM tile:
     1) Enlarge  — in-page pop-out window (no reconnect)
     2) Line state pill — Idle -> Standby -> On Air (one click to
        cycle), color-coding the tile border. Persists per line.
     3) Guest label — editable name field per tile. Persists.

   Include AFTER your own customized vms.js:
       <script src="vms.js"></script>
       <script src="vm-enhance.js"></script>

   State + labels are stored in localStorage (per browser/machine),
   so they survive page reloads and view switches.
   ============================================================= */
(function () {
  if (!window.createTile) {
    console.warn('[vm-enhance] include this AFTER vms.js');
    return;
  }

  var ICON_ENLARGE  = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>';
  var ICON_MINIMIZE = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 14 10 14 10 20"/><polyline points="20 10 14 10 14 4"/><line x1="14" y1="10" x2="21" y2="3"/><line x1="3" y1="21" x2="10" y2="14"/></svg>';
  var ICON_RESET    = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>';

  /* ---------- modal system (define only if vms.js didn't) ---------- */
  if (!window.openModal || !window.closeModal) {
    var MODAL_CSS =
      '.vm-modal-backdrop{position:fixed;inset:0;z-index:900;background:rgba(4,7,11,.74);' +
        '-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px);' +
        'opacity:0;pointer-events:none;transition:opacity .18s ease;}' +
      '.vm-modal-backdrop.show{opacity:1;pointer-events:auto;}' +
      '.tile.tile--modal{position:fixed;z-index:910;top:50%;left:50%;' +
        'width:min(92vw,1500px);height:min(88vh,950px);transform:translate(-50%,-50%);' +
        'border-color:var(--accent-line);' +
        'box-shadow:0 30px 90px rgba(0,0,0,.6),0 0 0 1px var(--accent-line);' +
        'animation:vm-pop .2s cubic-bezier(.2,.8,.25,1);}' +
      '.tile.tile--modal .tile__head{padding:11px 12px;}' +
      '.tile.tile--modal .tile__name{font-size:14px;}' +
      '.tile.tile--modal .tile__phone{font-size:12px;}' +
      'body.bare .tile.tile--modal .tile__head{display:flex;}' +
      '@keyframes vm-pop{from{opacity:.45;transform:translate(-50%,-50%) scale(.94);}' +
        'to{opacity:1;transform:translate(-50%,-50%) scale(1);}}';

    var _openTile = null;

    var ensureLayer = function () {
      var back = document.getElementById('vm-modal-backdrop');
      if (!back) {
        if (!document.getElementById('vm-modal-style')) {
          var s = document.createElement('style');
          s.id = 'vm-modal-style';
          s.textContent = MODAL_CSS;
          document.head.appendChild(s);
        }
        back = document.createElement('div');
        back.id = 'vm-modal-backdrop';
        back.className = 'vm-modal-backdrop';
        back.addEventListener('click', window.closeModal);
        document.body.appendChild(back);
        document.addEventListener('keydown', function (e) {
          if (e.key === 'Escape' && _openTile) window.closeModal();
        });
      }
      return back;
    };

    var setIcon = function (tile, open) {
      var b = tile.querySelector('.icon-btn[data-role="enlarge"]');
      if (!b) return;
      b.innerHTML = open ? ICON_MINIMIZE : ICON_ENLARGE;
      b.title = open ? 'Restore' : 'Enlarge';
      b.setAttribute('aria-label', b.title);
    };

    window.openModal = function (tile) {
      if (_openTile && _openTile !== tile) window.closeModal();
      var back = ensureLayer();
      _openTile = tile;
      tile.classList.add('tile--modal');
      back.classList.add('show');
      document.body.classList.add('vm-modal-open');
      setIcon(tile, true);
    };

    window.closeModal = function () {
      if (!_openTile) return;
      var tile = _openTile;
      _openTile = null;
      tile.classList.remove('tile--modal');
      var back = document.getElementById('vm-modal-backdrop');
      if (back) back.classList.remove('show');
      document.body.classList.remove('vm-modal-open');
      setIcon(tile, false);
    };
  }

  /* ---------- per-line state + label storage ----------
     Shared mode: when window.LINE_SYNC_URL is set, the server is the source
     of truth. localStorage is used only as an offline cache so the UI still
     works (read-only-ish, local) if the backend is unreachable.
     Local mode: no URL set -> behaves exactly as before (per-machine).      */
  var SYNC_URL = (window.LINE_SYNC_URL || '').replace(/\/+$/, '');
  var SYNCING  = !!SYNC_URL;

  var STORE = 'vip_lines';
  function loadAll() { try { return JSON.parse(localStorage.getItem(STORE) || '{}'); } catch (e) { return {}; } }
  function saveAll(m) { try { localStorage.setItem(STORE, JSON.stringify(m)); } catch (e) {} }
  function getRec(id) { if (!id) return {}; var m = loadAll(); return m[id] || {}; }

  function cachePatch(id, patch) {
    if (!id) return;
    var m = loadAll(); m[id] = Object.assign({}, m[id], patch); saveAll(m);
  }

  // server push (debounced per line for label typing; immediate for state)
  var pushTimers = {};
  function pushServer(id, patch, delay) {
    if (!SYNCING || !id) return;
    function doPut() {
      fetch(SYNC_URL + '/lines/' + encodeURIComponent(id), {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patch),
        keepalive: true
      }).then(function () { setSync('ok'); })
        .catch(function () { setSync('off'); });
    }
    if (delay) { clearTimeout(pushTimers[id]); pushTimers[id] = setTimeout(doPut, delay); }
    else doPut();
  }

  /* A user-initiated change: update local cache + UI immediately (optimistic),
     then push to the server. `delay` debounces label keystrokes.            */
  function patchRec(id, patch, delay) {
    cachePatch(id, patch);
    pushServer(id, patch, delay);
  }

  var STATES = ['idle', 'standby', 'onair'];
  var STATE_LABEL = { idle: 'IDLE', standby: 'STDBY', onair: 'ON AIR' };

  function lineKey(tile, vm) {
    if (vm && vm.id != null) return String(vm.id);
    if (tile.dataset && tile.dataset.vm) return String(tile.dataset.vm);
    var n = tile.querySelector('.tile__name');
    return n ? n.textContent.trim() : '';
  }

  function applyState(tile, state) {
    tile.classList.remove('line-idle', 'line-standby', 'line-onair');
    tile.classList.add('line-' + state);
    var pill = tile.querySelector('.line-state');
    if (pill) { pill.textContent = STATE_LABEL[state]; pill.dataset.state = state; }
  }

  /* ---------- styles (idempotent) ---------- */
  if (!document.getElementById('vm-controls-style')) {
    var st = document.createElement('style');
    st.id = 'vm-controls-style';
    st.textContent =
      /* enlarge button accent */
      '.icon-btn{color:var(--txt-dim);}' +
      '.icon-btn[data-role="enlarge"]{color:var(--accent);background:var(--accent-soft);border-color:var(--accent-line);}' +
      '.icon-btn[data-role="enlarge"]:hover{background:var(--accent);color:#06080c;border-color:var(--accent);}' +

      /* our pill replaces the decorative dot */
      '.tile.has-linestate .tile__dot{display:none;}' +

      /* state pill */
      '.line-state{flex:none;display:inline-flex;align-items:center;justify-content:center;' +
        'min-width:54px;padding:3px 8px;border:1px solid var(--line);border-radius:999px;' +
        'font-family:var(--mono);font-size:10px;font-weight:600;letter-spacing:.6px;text-transform:uppercase;' +
        'cursor:pointer;background:transparent;color:var(--txt-faint);' +
        'transition:background .14s,color .14s,border-color .14s,box-shadow .14s;}' +
      '.line-state:hover{filter:brightness(1.12);}' +
      '.tile.line-idle .line-state{color:var(--txt-faint);border-color:var(--line);background:transparent;}' +
      '.tile.line-standby .line-state{color:#f5c06b;border-color:rgba(245,166,35,.55);background:rgba(245,166,35,.14);}' +
      '.tile.line-onair .line-state{color:#fff;border-color:#ff4d4d;background:#e23636;font-weight:700;}' +

      /* tile border by state */
      '.tile.line-standby{border-color:rgba(245,166,35,.7)!important;box-shadow:0 0 0 1px rgba(245,166,35,.45);}' +
      '.tile.line-standby:focus-within{box-shadow:0 0 0 1px rgba(245,166,35,.45);}' +
      '.tile.line-onair{border-color:#ff4d4d!important;box-shadow:0 0 0 1px rgba(255,77,77,.6),0 0 24px rgba(255,77,77,.28);}' +
      '.tile.line-onair:focus-within{box-shadow:0 0 0 1px rgba(255,77,77,.6),0 0 24px rgba(255,77,77,.28);}' +
      '.tile.line-onair .tile__head{background:linear-gradient(180deg,rgba(226,54,54,.18),transparent);}' +

      /* on-air pulse */
      '@keyframes vip-onair-pulse{0%,100%{box-shadow:0 0 10px rgba(255,77,77,.45);}50%{box-shadow:0 0 18px rgba(255,77,77,.85);}}' +
      '.tile.line-onair .line-state{animation:vip-onair-pulse 1.7s ease-in-out infinite;}' +

      /* guest label */
      '.line-label{flex:1;min-width:36px;background:transparent;border:1px solid transparent;outline:none;' +
        'color:var(--txt);font-family:var(--sans);font-size:12px;font-weight:500;padding:2px 6px;border-radius:6px;' +
        'transition:background .12s,border-color .12s;}' +
      '.line-label::placeholder{color:var(--txt-faint);font-weight:400;font-style:italic;}' +
      '.line-label:hover{background:rgba(255,255,255,.045);}' +
      '.line-label:focus{background:rgba(255,255,255,.07);border-color:var(--accent-line);}' +

      /* reset-all toolbar button: amber hint, since it clears */
      '#vip-reset-all:hover{border-color:rgba(245,166,35,.55)!important;color:#f5c06b!important;}' +

      /* sync status chip */
      '.vip-sync-chip{display:inline-flex;align-items:center;gap:6px;padding:5px 9px;border-radius:7px;' +
        'font-family:var(--mono);font-size:10px;font-weight:600;letter-spacing:.6px;border:1px solid var(--line);' +
        'color:var(--txt-faint);background:transparent;white-space:nowrap;}' +
      '.vip-sync-chip::before{content:"";width:7px;height:7px;border-radius:50%;background:currentColor;}' +
      '.vip-sync-chip[data-sync="ok"]{color:#56d364;border-color:rgba(86,211,100,.4);background:rgba(86,211,100,.1);}' +
      '.vip-sync-chip[data-sync="off"]{color:#f5c06b;border-color:rgba(245,166,35,.5);background:rgba(245,166,35,.12);}' +
      '.vip-sync-chip[data-sync="local"]{color:var(--txt-faint);}';
    (document.head || document.documentElement).appendChild(st);
  }

  /* ---------- enhance one tile (idempotent) ---------- */
  function enhanceTile(tile, vm) {
    var head  = tile.querySelector('.tile__head');
    var tools = tile.querySelector('.tile__tools');
    var ident = tile.querySelector('.tile__ident');
    if (!head || !tools) return;

    var key = lineKey(tile, vm);
    var rec = getRec(key);
    var hadEnlarge = !!tools.querySelector('[data-role="enlarge"]');

    /* Enlarge button (skip if vms.js already added one) */
    if (!hadEnlarge) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'icon-btn';
      b.dataset.role = 'enlarge';
      b.title = 'Enlarge';
      b.setAttribute('aria-label', 'Enlarge');
      b.innerHTML = ICON_ENLARGE;
      b.addEventListener('click', function () {
        if (tile.classList.contains('tile--modal')) window.closeModal();
        else window.openModal(tile);
      });
      tools.insertBefore(b, tools.firstChild);
    }

    /* Line-state pill */
    if (!head.querySelector('.line-state')) {
      tile.classList.add('has-linestate');
      var pill = document.createElement('button');
      pill.type = 'button';
      pill.className = 'line-state';
      pill.title = 'Line status — click to cycle: Idle \u2192 Standby \u2192 On Air';
      pill.addEventListener('click', function (e) {
        e.stopPropagation();
        var cur = pill.dataset.state || 'idle';
        var next = STATES[(STATES.indexOf(cur) + 1) % STATES.length];
        applyState(tile, next);
        patchRec(key, { state: next });
      });
      pill.addEventListener('dblclick', function (e) { e.stopPropagation(); });
      head.insertBefore(pill, head.firstChild);
    }

    /* Guest label input */
    if (ident && !ident.querySelector('.line-label')) {
      var inp = document.createElement('input');
      inp.type = 'text';
      inp.className = 'line-label';
      inp.placeholder = 'Guest\u2026';
      inp.value = rec.label || '';
      inp.setAttribute('spellcheck', 'false');
      inp.addEventListener('input', function () { patchRec(key, { label: inp.value }, 400); });
      inp.addEventListener('dblclick', function (e) { e.stopPropagation(); });
      inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') inp.blur(); });
      ident.appendChild(inp);
    }

    /* Restore persisted state */
    applyState(tile, rec.state || 'idle');

    /* Header double-click to enlarge (only if WE own the enlarge feature) */
    if (!hadEnlarge && !head._vmDbl) {
      head._vmDbl = true;
      head.addEventListener('dblclick', function (e) {
        if (e.target.closest('.tile__tools') ||
            e.target.closest('.line-state') ||
            e.target.closest('.line-label')) return;
        if (tile.classList.contains('tile--modal')) window.closeModal();
        else window.openModal(tile);
      });
    }
  }

  /* ---------- reset all lines to Idle (end-of-show cleanup) ---------- */
  function resetAllLines() {
    var tiles = document.querySelectorAll('.tile');
    if (!tiles.length) return;
    var anyOnAir = false, i;
    for (i = 0; i < tiles.length; i++) {
      if (tiles[i].classList.contains('line-onair')) { anyOnAir = true; break; }
    }
    var msg = anyOnAir
      ? 'A line is still marked ON AIR.\nReset all lines to Idle and clear guest names?'
      : 'Reset all lines to Idle and clear guest names?';
    if (!window.confirm(msg)) return;
    saveAll({});
    if (SYNCING) {
      fetch(SYNC_URL + '/reset', { method: 'POST', keepalive: true })
        .then(function () { setSync('ok'); })
        .catch(function () { setSync('off'); });
    }
    for (i = 0; i < tiles.length; i++) {
      applyState(tiles[i], 'idle');
      var inp = tiles[i].querySelector('.line-label');
      if (inp) inp.value = '';
    }
  }

  function injectReset() {
    if (document.getElementById('vip-reset-all')) return;
    var btn = document.createElement('button');
    btn.id = 'vip-reset-all';
    btn.type = 'button';
    btn.className = 'ghost-btn';            // styled by both pages
    btn.title = 'Reset all lines to Idle and clear guest names';
    btn.innerHTML = ICON_RESET + '<span>Reset lines</span>';
    btn.addEventListener('click', resetAllLines);

    // Place just before the page's reload button (console: #reloadAll, wall: #wallReload).
    var anchor = document.getElementById('reloadAll') || document.getElementById('wallReload');
    if (anchor && anchor.parentNode) { anchor.parentNode.insertBefore(btn, anchor); return; }
    // Fallbacks.
    var ctrl = document.querySelector('.topbar .ctrl');
    if (ctrl) { ctrl.insertBefore(btn, ctrl.firstChild); return; }
    var bar = document.querySelector('.bar') || document.querySelector('.topbar');
    if (bar) bar.appendChild(btn);
  }

  /* ---------- live sync engine (shared mode only) ---------- */

  // Apply a remote record to any matching tile WITHOUT pushing back to the
  // server (avoids feedback loops). Never clobbers a label being edited.
  function applyRemote(id, rec) {
    cachePatch(id, rec);
    var tiles = document.querySelectorAll('.tile');
    for (var i = 0; i < tiles.length; i++) {
      if (lineKey(tiles[i], null) !== id) continue;
      if (rec.state) applyState(tiles[i], rec.state);
      var inp = tiles[i].querySelector('.line-label');
      if (inp && document.activeElement !== inp && rec.label !== undefined) inp.value = rec.label;
    }
  }

  function applySnapshot(map) {
    saveAll(map || {});
    var tiles = document.querySelectorAll('.tile');
    for (var i = 0; i < tiles.length; i++) {
      var id = lineKey(tiles[i], null);
      var rec = (map && map[id]) || { state: 'idle', label: '' };
      applyState(tiles[i], rec.state || 'idle');
      var inp = tiles[i].querySelector('.line-label');
      if (inp && document.activeElement !== inp) inp.value = rec.label || '';
    }
  }

  function applyResetRemote() {
    saveAll({});
    var tiles = document.querySelectorAll('.tile');
    for (var i = 0; i < tiles.length; i++) {
      applyState(tiles[i], 'idle');
      var inp = tiles[i].querySelector('.line-label');
      if (inp && document.activeElement !== inp) inp.value = '';
    }
  }

  function fetchAll() {
    if (!SYNCING) return;
    fetch(SYNC_URL + '/lines')
      .then(function (r) { return r.json(); })
      .then(function (m) { applySnapshot(m); setSync('ok'); })
      .catch(function () { setSync('off'); });   // keep showing local cache
  }

  var _es = null, _pollTimer = null;
  function connectStream() {
    if (!SYNCING) return;
    if (!window.EventSource) { startPolling(); return; }
    try { _es = new EventSource(SYNC_URL + '/events'); }
    catch (e) { startPolling(); return; }

    _es.addEventListener('snapshot', function (e) {
      try { applySnapshot(JSON.parse(e.data)); setSync('ok'); } catch (_) {}
    });
    _es.onmessage = function (e) {
      try {
        var ev = JSON.parse(e.data);
        if (ev.type === 'line') applyRemote(ev.id, { state: ev.state, label: ev.label });
        else if (ev.type === 'reset') applyResetRemote();
        setSync('ok');
      } catch (_) {}
    };
    _es.onopen = function () { setSync('ok'); };
    _es.onerror = function () {
      // EventSource auto-reconnects; reflect the gap and keep a slow poll as backup.
      setSync('off');
      startPolling(15000);
    };
  }

  function startPolling(interval) {
    if (!SYNCING || _pollTimer) return;
    _pollTimer = setInterval(fetchAll, interval || 3000);
  }

  /* ---------- sync status chip (toolbar) ---------- */
  var _chip = null;
  function setSync(state) {
    if (!_chip) return;
    if (!SYNCING) { _chip.textContent = 'LOCAL'; _chip.dataset.sync = 'local'; _chip.title = 'Local only — not shared across machines'; return; }
    if (state === 'ok') { _chip.textContent = 'SYNCED'; _chip.dataset.sync = 'ok'; _chip.title = 'Shared live across all operators'; }
    else { _chip.textContent = 'OFFLINE'; _chip.dataset.sync = 'off'; _chip.title = 'Sync unreachable — showing last known state (changes are local until reconnect)'; }
  }
  function injectChip() {
    if (document.getElementById('vip-sync-chip')) { _chip = document.getElementById('vip-sync-chip'); return; }
    var chip = document.createElement('span');
    chip.id = 'vip-sync-chip';
    chip.className = 'vip-sync-chip';
    var anchor = document.getElementById('vip-reset-all');
    if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(chip, anchor);
    else {
      var bar = document.querySelector('.bar') || document.querySelector('.topbar');
      if (bar) bar.appendChild(chip);
    }
    _chip = chip;
    setSync(SYNCING ? 'connecting' : 'local');
  }

  /* ---------- wrap createTile so every NEW tile is enhanced ---------- */
  var original = window.createTile;
  window.createTile = function (vm, opts) {
    var tile = original(vm, opts);
    try { enhanceTile(tile, vm); } catch (e) { console.warn('[vm-enhance]', e); }
    return tile;
  };

  /* ---------- patch any tiles already on the page ---------- */
  function patchExisting() {
    var nodes = document.querySelectorAll('.tile');
    for (var i = 0; i < nodes.length; i++) {
      try { enhanceTile(nodes[i], null); } catch (e) {}
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', patchExisting);
  else patchExisting();

  injectReset();
  injectChip();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { injectReset(); injectChip(); });
  }

  if (SYNCING) {
    fetchAll();        // fast paint of current shared state
    connectStream();   // live updates (SSE), polling fallback inside
  } else {
    setSync('local');
  }
})();
