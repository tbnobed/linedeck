# ViP Dante VM Console — shared line-state sync

Because the console and wall are opened from **multiple operator machines**,
line status (Idle / Standby / On Air) and guest names are stored on a small
shared backend instead of each browser. Changes appear on every screen live
(via Server-Sent Events), with polling as a fallback. If the backend is
unreachable — or you leave it unconfigured — the pages quietly fall back to
local-only behavior (per-machine), so nothing breaks.

## Files

| File | Where it goes | Notes |
|------|---------------|-------|
| `index.html`, `allvms.html`, `vms.js` | web root (`/plex/MU2/`) | `vms.js` is **your** customized copy — keep it |
| `vm-enhance.js` | same web root | the add-on (Enlarge, line state, labels, reset, sync) |
| `line_sync.py`, `requirements.txt`, `Dockerfile`, `docker-compose.yml` | wherever you run the API | the shared backend |

## 1. Run the backend

**Docker (recommended):**
```bash
docker compose up -d --build
# API now on http://<host>:8090  (state persisted in the line-sync-data volume)
```

**Or bare Python:**
```bash
pip install -r requirements.txt
uvicorn line_sync:app --host 0.0.0.0 --port 8090
```

Quick check: `curl http://<host>:8090/health` → `{"ok":true,...}`

## 2. Point the pages at it

In **both** `index.html` and `allvms.html`, set the one config line near the
bottom (just before `vm-enhance.js`):

```html
<script>window.LINE_SYNC_URL = "http://sys.trinity.local:8090";</script>
```

- Leave it `""` to stay local-only (no sharing).
- The toolbar shows a status chip: **SYNCED** (green), **OFFLINE** (amber,
  showing last-known state), or **LOCAL** (not configured).

CORS is open on the API, so the pages can be served from a different origin
than the API. If you'd rather keep everything same-origin, reverse-proxy the
API under your web root (e.g. Nginx `location /lines-api/ { proxy_pass ...; }`)
and set `LINE_SYNC_URL = "/lines-api"`. For SSE through Nginx, disable
buffering on that location: `proxy_buffering off;` (the API already sends
`X-Accel-Buffering: no`).

## API

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/lines` | all line records `{id:{state,label,updatedAt}}` |
| PUT | `/lines/{id}` | update one line `{state?, label?}` |
| POST | `/reset` | clear all lines (end-of-show) |
| GET | `/events` | SSE stream: `snapshot`, then `line` / `reset` events |
| GET | `/health` | liveness + subscriber count |

State is one of `idle`, `standby`, `onair`. Concurrent edits are last-write-wins.

## Scaling note

SSE fan-out is in-process, so run **one** worker (the Dockerfile does). A
handful of operators and 10–12 lines is trivial load for that. If you ever
need multiple workers / replicas, swap the in-process broadcast for Redis
pub/sub and run behind a load balancer — the client needs no changes.
